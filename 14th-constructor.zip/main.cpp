#include <iostream>

using namespace std;
class Square
{
private:
  int a = 5, b = 6;
  //a=lendth,b=width
public:

    void setA (int avalue)
    {
        a = avalue;
    };
    int getA ()
    {
        return a;
    };
    void setB (int bvalue)
    {
        b = bvalue;
    };
    int getB(){
        return b;
    };
    Square(int a,int b){
        a=0,b=0;
        cout<<"area ="<<a*b<<endl;
    }
    Square(){
        
        cout<<"area ="<<0<<endl;
    }
    Square(int a){
        
        cout<<"area ="<<a*a<<endl;
    }
};

int main ()
{   //int a=0;
   // int b=5
    Square square();
    Square square1(10,20);
    Square square2(50);
    
    
    cout << "Hello World"<<endl;
    
    return 0;
}
