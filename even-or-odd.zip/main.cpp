
#include <iostream>

using namespace std;


int main()
{
    int a, no, Even = 0, Odd = 0;

   cout << "numbers ";
   cin >> a;

    for (int i = 1; i <= a; i++) 
    {
        cout << "Enter number at position " << i << ": ";
        cin >> no;

        if (no % 2 == 0)
        {
            Even += no;
        } 
        else
        {
            Odd += no;
        }
    }

    cout << "Sum of even numbers is " << Even << endl;
    cout << "Sum of odd numbers is " << Odd << endl;

return 0;
}