#include <stdio.h>

int main()
{   int a;
    int b;
    scanf("%d",&a);
    scanf("%d",&b);
    int c[a][b];
    int d[a][b];
     for(int i = 0; i<a; i++){
         for(int j = 0; j < b; j++){
             printf(" \nenter value to store at %d %d",i,j);
             scanf("%d",&c[i][j]);
         }
    }  
     for(int i = 0; i<a; i++){
         for(int j = 0; j < b; j++){
             printf(" \nenter value to store at %d %d",i,j);
             scanf("%d",&d[i][j]);
         }
    }     
     for(int i = 0; i<=a; i++){
        for(int j = 0; j<=b; j++){
           printf("\n%d", c[i][j]*d[i][j]);
        }
    }   
    return 0;
}

