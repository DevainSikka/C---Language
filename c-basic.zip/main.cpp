#include <iostream>

using namespace std;

int main()
{   int a=10;
    int b=20;
    int c=a+b-a*b+a/b;
    int d=a%b;
    int x;
    cout<<"enter the value of x";
    cin>>x;
    cout<<"x = "<<x;
    
    cout<<"\nc " << c <<"\nd "<<d;
    
    return 0;
}