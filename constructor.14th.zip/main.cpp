#include <iostream>
#include <string.h>

using namespace std;
class Student{
    private:
        string name;
        
public:
    Student(string Studentname="unkown"){
        name=Studentname;
    };
    string getname(){
        return name;
    };
       
    
};
int main()
{   Student student1;
    Student student2("goku");
    cout<<student1.getname()<<endl<<student2.getname();
    

    return 0;
}