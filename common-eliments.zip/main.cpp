#include <iostream>

using namespace std;

int main()
{   
    /*int i = 5;
    int array1[i] = {10,23,12,43,122};
    int array2[i] = {23,12,10,5,4}; */
    
    int i;
   
    cout<<"size of array = ";
    cin>>i;
     int array1[i];
    int array2[i];
   for(int a=0;a<i;a++){
        cout<<"value at array1[a]";
        cin>>array1[a];
    }
    for(int a=0;a<i;a++){
         cout<<"value at array2[i]";
         cin>>array2[a];
     } 
     
     }
    for(int a=0;a<i;a++){
        for(int b=0;b<i;b++){
            if(array1[a] == array2[b]){
                
                cout<<"\t "<<array1[a];
             }
            
        }
    }
    

    return 0;
}