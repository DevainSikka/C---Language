#include <stdio.h>
#include <string.h>
struct studentinfo{
    char name[20];
    int rollno;
    int a;
    int b;
    int c;
    //a=marks in c language
    //b=marks in c++ language
    //c=marks in java language
};
 int main()
{   int i;
    printf("no. of values you wnt to store ");
    scanf("%d",&i);
    struct studentinfo s[i];
    for(int x=0;x<i;x++){
         printf("\nenter the name of sttudent ");
        scanf("%s",&s[x].name);
         printf("\nenter the value of rollno to store at  %d",x);
        scanf("%d", &s[x].rollno);
         printf("\nenter the marks in c %d ",x);
        scanf("%d", &s[x].a);
         printf("\nenter the marks in c++ %d ",x);
        scanf("%d", &s[x].b);
         printf("\nenter the marks in java %d ",x);
        scanf("%d", &s[x].c);
        
    }
    int highestinc = s[0].a;
    int highestincss=s[0].b;
    int highestinjava=s[0].c;
    int studentwithhighestinc=0;
    int studentwithhighestincss=0;
    int studentwithhighestinjava=0;
    for(int j=0; j<i; j++){
          if(highestinc < s[j].a){
            highestinc = s[j].a;
            studentwithhighestinc=i;
        }
         if(highestincss<s[j].b){
            highestincss=s[j].b;
            studentwithhighestincss=i
            
        }
        if(highestinjava<s[j].c){
            highestinjava=s[j].c;
            studentwithhighestinjava=0;
            
        }
        
       
   }
    printf("highest marks in c %d \n",highestinc);
    printf("highest marks in c++%d\n",highestincss);
    printf("highest marks in java%d\n",highestinjava);
    printf("student with highest marks in c %d",s[studentwithhighestinc].name);
    printf("student with highest marks in c %d",s[studentwithhighestincss].name);
    printf("student with highest marks in c %d",s[studentwithhighestinjava].name);
    return 0;
}
