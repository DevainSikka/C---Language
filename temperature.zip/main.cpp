#include <iostream>

using namespace std;

int main()
{   double fahrenheit;
    //int celsius=(fahrenheit-32)*5/9;
    
    cout<<"temperature in fahrenheit = ";
    cin>>fahrenheit;
    double celsius=(fahrenheit-32)*5/9;
    cout<<"celsius = "<<celsius;

    return 0;
}