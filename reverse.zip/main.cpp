#include <iostream>

using namespace std;

int main() {
    int number, reversedNo = 0, count = 0, sum = 0;
    
    cout << "Enter a number: ";
    cin >> number;
    
    while (number != 0) {
        int digit = number % 10;
        reversedNo = reversedNo * 10 + digit;
        number /= 10;
        count++;
        sum += digit;
        
    }
    float average= (float)sum/count;
    cout << "Reversed number: " << reversedNo << endl;
    cout << "average is: "<< average<< endl;
     return 0;
}

