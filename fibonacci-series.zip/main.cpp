#include <iostream>
using namespace std;

int main() {
    int n, a = 0, b = 1, c = 0;

    cout << "Enter the number of terms: ";
    cin >> n;

    cout << "Fibonacci Series: ";

    for (int i = 1; i <= n; ++i) {
        if(i == 1) {
            cout << a << endl;
            continue;
        }
        if(i == 2) {
            cout << b << endl;
            continue;
        }
        
        c = a + b;
        a = b;
        b = c;
        
        cout << c << endl ;
    }    
    return 0;
}    