#include <iostream>

using namespace std;
int result(int power,int baseno){
    int endresult=baseno;
    
    for(int i=1;i<power;i++){
        endresult*=baseno;
      //  cout<<endresult<<endl;
    }
    return endresult;
}

int main()
{   int baseno,power;
    cout<<"base number = ";
    cin>>baseno;
    cout<<"power = ";
    cin>>power;
   cout<< "After calculating "<<result(power,baseno);
    return 0;
}