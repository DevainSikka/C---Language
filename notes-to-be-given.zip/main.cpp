#include <iostream>

using namespace std;

int main()
{   int number;
    
    cout<<"enter the size of currency denomination";
    cin>>number;
    int denomination[number];
    for(int i=0;i<number;i++){
        cout<<"Enter the currency denomination";
        cin>>denomination[i];
    }
        for(int i = 0; i < number; i++){
            for(int j = 0; j < number; j++){
                if(denomination[i] > denomination[j]){
                    int temp = denomination[i];
                    denomination[i] = denomination[j];
                    denomination[j] = temp;
            }
        }
    }
    int ammount;
    cout<<"enter the value you want to pay";
    cin>>ammount;
    // for(int i=0;i<number;i++){
    //     if(denomination[i]>denomination[0]){
    //             denomination[0]=denomination[i];
    //     }if(denomination[i]>denomination[1]){
    //             denomination[1]=denomination[1];
    //     }if(denomination[i]>denomination[2]){
    //             denomination[2]=denomination[i];
    //     }if(denomination[i]>denomination[3]){
    //             denomination[3]=denomination[i];
    //     }if(denomination[i]>denomination[4]){
    //             denomination[4]=denomination[i];
    //     }
        
        
    // }
    
    int payment[number];
    for(int i=0;i<number;i++){
        if(ammount>=denomination[i]){
            payment[i] = ammount / denomination[i];
            ammount %=  denomination[i];
        }
    }
    cout<<"Your payment approach in order to give min no of notes will be";
     for(int i=0;i<number;i++){
         if(payment[i]>0){
         cout << denomination[i] << " : " << payment[i] << endl;
     }
         
     }
    
    return 0;
}
