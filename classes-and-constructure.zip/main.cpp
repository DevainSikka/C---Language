#include <iostream>

using namespace std;

//oops
//class and objects
//class - blueprint - functions and data members , access specifier - public, private, protected
//objects - real world entity

//getters and setters

//constructor - call class object create
//constructor 2 types - default and parameterised
//Constructor properties - 1. special type of function, 2. Same name as that of class 3. It does not have return type 

//function overloading and constructor overloading
//functions should have same name
//functions should have either different parameter count or different argument type

class Rectangle{
    private :
        int a, b;
    
    public :
    
    //constructor overloading
        Rectangle(){
            a = 100;
            b = 20;
            cout<<"in constructor "<<endl;
        }
        
        Rectangle(int aValue){
            cout<<"in parameterised constructor "<<aValue<<endl;
        }
        
        Rectangle(float value){
            cout<<"in parameterised constructor for b "<<value<<endl;
        }
        
        Rectangle(int a, int b){
            cout<<"value of a "<<a<<" Value of b "<<b<<endl;
        }
        int getA(){
            return a;
        }
        void setA(int aValue){
            a = aValue;
        }
        
        void getArea(){
            cout<<"Area of rectangle is "<<a*b;
        }
};

int main()
{
    Rectangle rectangle;
    Rectangle rectangle1(20);
    Rectangle rect(12,45);
  //  rectangle.setA(10);
    
    cout<<"Hello World "<<rectangle.getA()<<" size of rectangle " << sizeof(rectangle)<<endl;
    
    rectangle.getArea();

    return 0;
}