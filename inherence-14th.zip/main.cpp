#include <iostream>

using namespace std;
class Mammals{
    public:
        void speak1(){
            cout<<"i am mammal"<<endl;
        }
};
class MarineAnimals{
    public:
        void speak2(){
            cout<<"i am marineAnimal"<<endl;
        }
};    
class Bluewhale: public Mammals, public MarineAnimals{
    public:
        void speak3(){
            cout<<"i am both mammal and marineAnimal"<<endl;
        }
};  

int main()
{   Mammals mammals;
    mammals.speak1();
    MarineAnimals marineAnimals;
    marineAnimals.speak2();
    Bluewhale bluewhale;
    bluewhale.speak3();
    bluewhale.speak1();
    bluewhale.speak2();
    return 0;
}
