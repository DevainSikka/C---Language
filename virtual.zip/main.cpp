#include <iostream>

using namespace std;
class A{
    public:
        virtual void functionA(){
            cout<<"hello my friend";
        }
           
        
};
class B{
    public:
        virtual void functionA() {
            
        }
};
class C : public A, public B{
    public:
        void functionA(){
            
        }
        
};
int main(){
    A a;
    a.functionA();
    C c;
    c.functionA();
    return 0;
}