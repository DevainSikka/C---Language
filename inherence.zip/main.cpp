#include <iostream>
using namespace std;
class square{
   public: 
    int a;
};
class Shape:  square
{  
    public:
    void area(int a){
    cout<<"area =" <<a*a<<endl;
    }
};
int main()
{
    Shape shape;
    shape.area(10);
    cout<<"Hello World";

    return 0;
}