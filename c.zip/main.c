#include <stdio.h>
int main()
{   int studentid[5]={1111,2222,3333,4444,5555};
    char* lastname[5]={"sikka","sharma","verma","henry","ahuja"};
    int m1[5]={10,20,30,40,50};
    int m2[5]={11,22,33,44,55};
    int total[5]={21,42,63,84,105};
    char grade[5]={'a','b','c','d','e'};
    for(int i=0;i<4;i++){
        printf("student id of %d is %d \n",i,studentid[i]);
        printf(" last name of %d is %s \n",i,lastname[i]);
        printf(" martks in 1 of %d is %d \n",i, m1[i]);
        printf(" marks in 2 of %d is %d \n",i,m2[i]);
        printf(" grade of %d is %c \n",i,grade[i]);
    }
    for(int i=0;i<4;i++){
        if(total[i]>35){
            printf("%d",total[i]);
        }
        if(grade[i]=='a'){
            printf("%c",grade[i]);
        }
    }
    return 0;
}