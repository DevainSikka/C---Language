#include <iostream>
using namespace std;
int series(int a){
    if(a == 0)
        return 0;
    else if(a == 1)
       return 1 ;
    else 
        return series(a-1) + series(a-2);
}

int main()
{
    //cout<< sum(5,10);
    int a ;
  //  int b = 1;
//    int c = 0;
    cout<<"enter the value of series ";
    cin>> a ;
    
    cout<< "series is ";
    for (int i=0;i<a;i++){
        cout << series(i)<<endl;
    }
    return 0;
}


