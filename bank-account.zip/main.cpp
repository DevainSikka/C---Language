#include <iostream>

using namespace std;
class Bank{
    public:
        
        string holderName;
        int accountNumber;
        int ammountinbank;
        int ammount;
        int Time;
        
        virtual void deposit() = 0;
        virtual void withdrawl() = 0;
        virtual void interest() = 0;
        double calculateAmount(){
            return ammount*5*Time/100;
        }
        
        void getInformation(){
             cout<<"Holder name ";
        cin>>holderName;
        cout<<"enter your account number ";
        cin>>accountNumber;
        cout<<"ammount you have in your account ";
        cin>>ammountinbank;
        }
        
};
class Sbi : public Bank{
    public:
        
        void deposit(){
        
            cout<< "enter the ammount you want to deposit ";
            cin>>ammount;
             ammountinbank = ammountinbank + ammount;
            cout<<"woohoo money is deposited "<<ammountinbank;
        }
        void withdrawl(){
            
            cout<<"enter the money you want to withdraw";
            cin>>ammount;
            if(ammount>ammountinbank){
                cout<<"sorry you do not have that much money in your account";
                
            }
            else{
                ammountinbank = ammountinbank - ammount;
                cout<<"here is your money after withdrawing amount "<<ammountinbank;
                cout<<ammountinbank;
            }
            
        }
        void interest(){
            
            cout<< "enter the ammount you want to deposit ";
            cin>>ammount;
            cout<<"for how much time (year)";
            cin>>Time;
            cout<< "rate of interest is 5%"<<endl; 
            cout<< "profit will be "<<calculateAmount();

        }
        
};
class Pnb : public Bank{
    public:
        
        void deposit(){
            cout<< "enter the ammount you want to deposit ";
            cin>>ammount;
            ammountinbank = ammountinbank + ammount;
            cout<<"woohoo money is deposited "<<ammountinbank;
            
        }
        void withdrawl(){
            cout<<"enter the money you want to withdraw";
            cin>>ammount;
            if(ammount>ammountinbank){
                cout<<"sorry you do not have that much money in your account";
                
            }
            else{
                ammountinbank = ammountinbank - ammount;
                cout<<"here is your money after withdrawing amount "<<ammountinbank;
                cout<<ammountinbank;
            }
        }
        void interest(){
            cout<< "enter the ammount you want to deposit ";
            cin>>ammount;
            cout<<"for how much time(year) ";
            cin>>Time;
            cout<< "rate of interest is 5%"<<endl; 
            cout<< "profit will be "<<calculateAmount();
            
        }
};
int main()
{   
    Sbi sbi;
    Pnb pnb;
    int name;
    string money;
    cout<<"name of bank account you have "<<endl<<"sbi or pnb  "<<"press 1 for sbi or 2 for pnb ";
    cin>>name;
    if(name == 1){
        sbi.getInformation();
        cout<<"to deposit money press d "<<"   to withdraw money press w "<<"   to check interest press i "<<endl;
        cin>>money;
        if(money == "d" || money == "D"){
            
            sbi.deposit();
        }
        else if(money == "w"|| money=="W"){
            sbi.withdrawl();
        }
        else if(money == "i"|| money == "I"){
            sbi.interest();
        }else{
            
        }
        
    }
    if(name == 2){
       pnb.getInformation();
       cout<<"to deposit money press d "<<"   to withdraw money press w "<<"   to check interest press i "<<endl;
        cin>>money;
        if(money == "d" || money == "D"){
            pnb.deposit();
        }
        else if(money == "w"|| money=="W"){
            pnb.withdrawl();
        }
        else if(money == "i"|| money == "I"){
            pnb.interest();
        }else{
            
        }
    
   
    }
    

    return 0;
}

